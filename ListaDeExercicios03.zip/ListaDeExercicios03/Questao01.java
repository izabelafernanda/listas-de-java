//Autor: Izabela Fernanda Silva //
// Data: 09/10/21 //

import java.util.Scanner;

public class Questao01 {

    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);

        // Imprimindo e declarando as variáveis.
        System.out.println("Digite o número de alunos: ");
        int totalAlunos = entrada.nextInt();
        int n = 1;

        // While faz a repetição do número indeterminado de alunos inserido.
        while (n <= totalAlunos) {

            // Imprimindo e recebendo as notas.
            System.out.println("Digite a nota 1 do aluno: " + n);
            int nota1 = entrada.nextInt();

            System.out.println("Digite a nota 2 do aluno: " + n);
            int nota2 = entrada.nextInt();

            System.out.println("Digite a nota 3 do aluno: " + n);
            int nota3 = entrada.nextInt();

            System.out.println("Digite a opção A (média aritmética) ou P (média ponderada): ");
            char opcao = entrada.next().charAt(0);

            // Invocando o método com a variável media.
            int media = calculaMedia(nota1, nota2, nota3, opcao);

            // Imprimindo a media do aluno com o número de alunos.
            System.out.println("media do aluno " + n + " é " + media);

            // Termina a repetição até o número inserido.
            n++;
        }

        entrada.close();
    }

    // Método função.
    public static int calculaMedia(int nota1, int nota2, int nota3, char opcao) {

        // Declarando a variável media.
        int media = 0;

        // Condição que determina verifica a opção se a média é ponderada ou aritmética.
        if (opcao == 'A' || opcao == 'a') {
            media = nota1 + nota2 + nota3 / 3;

        // Condição que determina a média ponderada. 
        } else if (opcao == 'P' || opcao == 'p') {
            media = (nota1 * 5 + nota2 * 3 + nota3 + 2) / 5 + 3 + 2;
        }

        // Retorna o método. 
        return media;
    }
}
