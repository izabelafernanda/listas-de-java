//Autor: Izabela Fernanda Silva 
//Data: 10/10/2021 

import java.util.Scanner;

public class Questao10 {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);

        // Declarando a variável idade.
        int idade;

        // Imprimindo e recebendo a idade do nadador.
        System.out.println("Digite a idade do nadador: ");
        idade = entrada.nextInt();

        // Invoca a função para o tipo categoria.
        String cat = categoria(idade);

        // Imprime o resultado idade e sua categoria.
        System.out.println("A idade é: " + cat);

        entrada.close();

    }

    // Método função.
    public static String categoria(int idade) {

        // Iniciando a variável string.
        String categoria = "";

        // Condição que verifica se a idade é de 5 a 7.
        if (idade >= 5 && idade <= 7) {
            categoria = "Categoria F";
        }

        // Condição que verifica se a idade é de 8 a 10.
        if (idade >= 8 && idade <= 10) {
            categoria = "Categoria E";
        }

        // Condição que verifica se a idade é de 11 a 13.
        if (idade >= 11 && idade <= 13) {
            categoria = "Categoria D";
        }

        // Condição que verifica se a idade é de 14 e 15.
        if (idade >= 14 && idade <= 15) {
            categoria = "Categoria C";
        }

        // Condição que verifica se a idade é de 16 e 17.
        if (idade >= 16 && idade <= 17) {
            categoria = "Categoria B";
        }

        // Condição que verifica se a idade é acima de 18.
        if (idade >= 18) {
            categoria = "Categoria A";

        }

        // Retorna a categoria da idade.
        return categoria;
    }

}