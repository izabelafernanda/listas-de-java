//Autor: Izabela Fernanda Silva 
//Data: 09/10/2021

import java.util.Scanner;

public class Questao04 {

    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);

        System.out.println("Digite a quantidade de conjuntos: ");
        int N = entrada.nextInt();

        // While realiza a repetição dos conjuntos lendo um determinado número de
        // conjuntos.
        while (N > 0) {

            // Declarando a variável double para os valores reais que serão inseridos.
            double x, y, z;

            // Imprimindo na tela os valores reais digitados.
            System.out.println("Digite 3 valores reais: (exemplo: 1/2, 5, -20");
            x = entrada.nextDouble();
            y = entrada.nextDouble();
            z = entrada.nextDouble();

            // Invocando o método calculaTriangulo.
            calculaTriangulo(x, y, z);

            // A repetição dos conjuntos diminui o valor do N até o zero.
            N--;
        }
        entrada.close();
    }

    // Método ponto de chamada.
    public static void calculaTriangulo(double x, double y, double z) {

        // Condição para verificar se o comprimento dos 3 lados são iguais.
        if (x < y + z && y < x + z && z < y + x) {

            if (x == y && y == z) {
                System.out.println("Triângulo Equilátero");
            }
            // Condição para verificar se o comprimento de pelo menos 2 lados são iguais.
            if (x == y || y == z) {
                System.out.println("Triângulo Isósceles");
            }
            // Condição para verificar se o comprimento de nenhum dos lados são iguais.
            if (x != y && y != z)
                System.out.println("Triângulo Escaleno");
        } else {
            System.out.println("Não é um triângulo.");
        }
    }

}
