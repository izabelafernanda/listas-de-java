//Autor: Izabela Fernanda Silva 
//Data: 09/10/2021

import java.util.Scanner;

public class Questao03 {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);

        System.out.println("Digite a quantidade de conjuntos: ");
        int N = entrada.nextInt();

        // While realiza a repetição dos conjuntos lendo um determinado número de
        // conjuntos.
        while (N > 0) {

            // Declarando as variáveis dos valores que serão inseridos.
            int valor1 = 0;
            int valor2 = 0;
            int valor3 = 0;

            // Imprimindo na tela os valores digitados.
            System.out.println("Digite 3 valores inteiros: (exemplo: 1, 2, 3)");
            valor1 = entrada.nextInt();
            valor2 = entrada.nextInt();
            valor3 = entrada.nextInt();

            // Invocando o método valores.
            valores(valor1, valor2, valor3);

            // A repetição dos conjuntos diminui o valor do N até o zero.
            N--;
        }
        entrada.close();
    }

    // Método ponto de chamada.
    public static void valores(int valor1, int valor2, int valor3) {

        // Variável para armazenar o número.
        int temporario;

        // Condições para determinar a ordem crescente.
        if (valor1 > valor2) {
            temporario = valor1;
            valor1 = valor2;
            valor2 = temporario;

        }
        if (valor2 > valor3) {
            temporario = valor3;
            valor3 = valor2;
            valor2 = temporario;

        }
        if (valor1 > valor2) {
            temporario = valor1;
            valor1 = valor2;
            valor2 = temporario;

        }

        // Imprime o resultado na tela.
        System.out.println("Ordem crescente: " + valor1 + " " + valor2 + " " + valor3);

    }

}
