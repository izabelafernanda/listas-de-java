//Autor: Izabela Fernanda Silva 
//Data: 09/10/2021

import java.util.Scanner;

public class Questao05 {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);

        System.out.println("Número de alunos: ");
        int N = entrada.nextInt();

        // While realiza a repetição dos conjuntos lendo um determinado número de
        // conjuntos.
        while (N > 0) {

            // Declarando a variável nota.
            int nota;
            System.out.println("Insira a média do aluno:");
            nota = entrada.nextInt();

            // Invocando o método conceitoMedia.
            conceitoMedia(nota);

            // A repetição dos alunos diminui o valor do N até o zero.
            N--;
        }
        entrada.close();
    }

    // Método ponto de chamada.
    public static void conceitoMedia(int nota) {

        // Condição que verifica se a nota é até 39.
        if (nota <= 39) {
            System.out.println("Conceito F");
        }

        // Condição que verifica se a nota é de 40 a 59.
        if (nota >= 40 && nota <= 59) {
            System.out.println("Conceito E");
        }

        // Condição que verifica se a nota é de 60 a 69.
        if (nota >= 60 && nota <= 69) {
            System.out.println("Conceito D");
        }

        // Condição que verifica se a nota é de 70 a 79.
        if (nota >= 70 && nota <= 79) {
            System.out.println("Conceito C");
        }

        // Condição que verifica se a nota é de 80 a 89.
        if (nota >= 80 && nota <= 89) {
            System.out.println("Conceito B");
        }

        // Condição que verifica se a nota é maior que 90.
        if (nota >= 90)
            System.out.println("Conceito A");
    }
}
