//Autor: Izabela Fernanda Silva 
//Data: 10/10/2021 

import java.util.Scanner;

public class Questao09 {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);

        // Declarando as variáveis. 
        int N;
        int totalNotas = 0;
        int totalAlunos = 0;

        // Imprimindo e recebendo o número de notas que serão inseridas.
        System.out.println("Insira o número de notas: ");
        N = entrada.nextInt();

        // While faz a repetição do número indeterminado de notas. 
        while (N > 0) {

            // Declarando e recebendo a Variável nota.
            int nota;
            System.out.println("Digite a nota: ");
            nota = entrada.nextInt();

            // Condição se a nota é maior ou igual a 6, o aluno é aprovado. 
            if (nota >= 6) {

                // Soma as notas e soma o número de alunos. 
                totalNotas += nota;
                totalAlunos++;

                System.out.println("Aluno aprovado.");
            } else {
                System.out.println("Aluno reprovado.");
            }

            // Terminando a repetição até o número que foi inserido. 
            N--;

        }

        // Invocando o método função com a variável media. 
        double media = calculaMedia(totalNotas, totalAlunos);
        System.out.println("A média dos aprovados é: " + media);


        entrada.close();

    }

    // Método função. 
    public static double calculaMedia(int totalNotas, int totalAlunos) {

        // Retornando a média dos alunos aprovados. 
        return totalNotas / totalAlunos;
    }
}
