//Autor: Izabela Fernanda Silva 
//Data: 10/10/2021

import java.util.Scanner;

public class Questao07 {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);

        System.out.println("Digite quantos números você vai verificar: ");
        int N = entrada.nextInt();

        // While realizando a repetição para N números que serão inseridos.
        while (N > 0) {

            // Imprime e recebe os números inteiros positivos ou negativos.
            System.out.println("Digite um número inteiro: ");
            int num = entrada.nextInt();

            // Condições que invoca a função para dizer se número é negativo ou positivo.
            if (valorlog(num)) {

                System.out.println("O número é negativo: " + num);

            } else {

                System.out.println("O número é positivo: ");
            }

            // Finaliza a repetição até o número inserido.
            N--;
        }
        entrada.close();
    }

    // Método função valor lógico.
    public static boolean valorlog(int num) {

        // Condição se o número for menor que 0, retorna verdadeiro pela função.
        if (num < 0) {
            return true;

            // Senão, retorna falso pela função.
        } else {
            return false;
        }

    }

}
