//Autor: Izabela Fernanda Silva 
//Data: 10/10/2021 

import java.util.Scanner;

public class Questao08 {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);

        System.out.println("Digite um valor inteiro e positivo: ");
        int num = entrada.nextInt();

        // Condição que determina o número inserido sendo um inteiro positivo.
        if (num >= 0) {

            // Invoca a função para o resultado S.
            double S = equacao(num);
            System.out.println("O valor é: " + S);

            // Condição, se não, determina quando o número insiderido não for um inteiro
            // positivo.
        } else {
            System.out.println("O número não é inteiro e positivo.");
        }
        entrada.close();
    }

    // Método função.
    public static double equacao(int S) {

        // Declarando a variável da função.
        double resultado = 1.0;

        // Condição que determina S maior que 1.
        if (S > 1) {

            // Cálculo do fatorial para cada número da série.
            for (int val = 2; val <= S; val++)
                resultado += (Math.pow(val, 2) + 1) / (val + 3);
        }
        // Retorna o resultado do cálculo da função.
        return resultado;
    }

}
