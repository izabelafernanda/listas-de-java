//Autor: Izabela Fernanda Silva 
//Data: 09/10/2021

import java.util.Scanner;

public class Questao06 {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);

        // Declaração da variável da função.
        double S;

        // Imprimindo na tela o valor de N.
        System.out.println("Digite um valor inteiro e positivo: ");
        int N = entrada.nextInt();

        // Invocando o método atribuindo o valor dele.
        S = CalculaSerie(N);
        System.out.println("O valor da função é: " + S);

        
        entrada.close();
    }

    // Método da função.
    public static double Fatorial(int S) {

        // Declarando a Variável resultado da função.
        double resultado = 1.0;

        // Condição se o resultado da função é maior que 1.
        if (S > 1) {

            // Cálculo do fatorial.
            for (int val = 2; val <= S; val++) {
                resultado *= val;
            }
        }

        // Retorna o resultado do cálculo da função.
        return resultado;

    }

    // Método função.
    public static double CalculaSerie(int N) {

        // Declarando as variáveis do resultado da função.
        double S = 0;
        int sinal = 1;

        // Cálculo do fatorial para cada número da série.
        for (int i = 1; i <= N; i++) {
            S += sinal / Fatorial(i);
            sinal *= (-1);
        }
        // Retorna o resultado do cálculo da função.
        return S;
    }

}
