
// Data: 09/09
// Autora: Izabela Fernanda Silva

package atividades;
import java.util.Scanner;
public class Questao08 {
	public static void main (String [] args) {
		Scanner entrada = new Scanner (System.in); //Scanner recebe os valores digitados.
		System.out.println("Insira o valor do sal�rio: "); //System.out.println imprime o texto pulando a linha.
		int salario = entrada.nextInt(); //int declara a vari�vel. 
		System.out.println("Digite uma op��o: "); //System.out.println imprime o texto pulando a linha.
		String opcao = entrada.next(); //String recebendo as op��es de sal�rio.
		float novosalario = 0; //float, declarando a vari�vel do novo sal�rio.
		switch (opcao.toUpperCase()) { //to.UpperCase transformando o digito da op��o em letra mai�scula.
		case "A":
			novosalario = salario + salario/100*8; //condi��o do aumento de 8% no sal�rio.
			break; //break interrompe o processamento.
		case "B":
			novosalario = salario + salario/100*11; //Condi��o do aumento de 11% no sal�rio.
			break; //break interrompe o processamento.
		case "C": 
			if (salario <= 1000) 
			novosalario = salario + 350; //Condi��o de aumento fixo no sal�rio de 350, se ele for menor ou igual a 1000.
			else if (salario >=1000)
			novosalario = salario + 200; //Condi��o de aumento fixo no sal�rio de 200, se ele foi maior ou igual a 1000.
			break; //Interrompe o processamento. 

		} 
		System.out.println("O novo sal�rio � de: "+novosalario);
		
	}

}
