// Data: 04/09
// Autora: Izabela Fernanda Silva

package atividades;
import java.util.Scanner;
public class Questao03 {
	public static void main(String[]args) { 
		Scanner entrada = new Scanner(System.in); //Scanner recebe os valores digitados.
		System.out.println("Digite seu ano de nascimento: "); //System.out.println imprime o texto pulando a linha.
		int anodenascimento = entrada.nextInt(); //int insere o ano de nascimento. 
		int idade = 2021-anodenascimento; //int o ano inserido, e vai ser subtra�do ao ano atual. 
		System.out.print("Voc� j� fez anivers�rio esse ano?"); //System.out.println imprime o texto pulando a linha.
		String resposta = entrada.next(); //String recebe a resposta.
		if (resposta.equals("N")) { //O operador == n�o funciona no String, utilizamos equals verificando a condi��o se a pessoa n�o fez anivers�rio nesse ano.
			idade = idade-1; //Ajustando a idade de acordo com o anivers�rio.
		}
		if (idade>=18) { //if, condi��o que verifica se a pessoa est� apta para tirar carteira de habilita��o. 
			System.out.println("Voc� tem "+idade+" anos."); //System.out.println imprime o texto pulando a linha.
			System.out.println("Voc� � maior de 18 anos, est� apto para tirar Carteira de Habilita��o."); //System.out.println imprime o texto pulando a linha.
		}else { //else, condi��o que verifica a idade da pessoa, e se ela � menor de 18 anos n�o est� apta para tirar carteira de habilita��o.
			System.out.println("Voc� tem "+idade+" anos."); //System.out.println imprime o texto pulando a linha.
			System.out.println("Voc� � menor de 18 anos, n�o est� apto para tirar Carteira de Habilita��o."); //System.out.println imprime o texto pulando a linha.
		    
		}
	}
}
