// Data: 09/09
// Autora: Izabela Fernanda Silva

package atividades;
import java.util.Scanner;
public class Questao09 {
	public static void main (String [] args) {
		Scanner entrada = new Scanner(System.in); //Scanner recebe os valores digitados.
		System.out.println("Insira um simbolo: "); //System.out.println imprime o texto pulando a linha.
		String simbolo = entrada.next(); //String recebe textos.
		switch (simbolo) { //switch, dado um valor, verifica v�rias condi��es.
		case "<": //case condi��o do simbolo de menor.
			System.out.println("Sinal de menor."); //System.out.println imprime o texto pulando a linha.
			break; //break interrompe o processamento.
		case ">":  //case condi��o do simbolo maior.
			System.out.println("Sinal de maior."); //System.out.println imprime o texto pulando a linha.
			break; //break interrompe o processamento.
		case "=": //case condi��o do simbolo igual.
			System.out.println("Sinal de igual."); //System.out.println imprime o texto pulando a linha.
			break; //break interrompe o processamento.
		default: //default determina a condi��o padr�o.
		System.out.println("Outro sinal.");	//System.out.println imprime o texto pulando a linha.
			
		}
	}
}
