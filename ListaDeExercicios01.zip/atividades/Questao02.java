
// Data: 04/09
// Autora: Izabela Fernanda Silva

package atividades;
import java.util.Scanner; 
public class Questao02 {
	public static void main(String[]args) { 
		Scanner entrada = new Scanner(System.in); //Scanner recebe os valores digitados.
		System.out.println("Digite um valor: "); //System.out.println imprime o texto pulando a linha.
		int num1 = entrada.nextInt(); //int insere o primeiro n�mero.
		System.out.println("Digite outro valor: "); //System.out.println imprime o texto pulando a linha.
		int num2 = entrada.nextInt(); //int insere o segundo n�mero.
		int resultado = num1+num2; //int insere o resultado da soma dos dois n�meros. 
		if(resultado >=10) { //if se o resultado for maior que 10. 
			resultado = resultado+5; //o resultado maior que 10 acrescenta a soma 5.
		}else {
			resultado = resultado+7; //else, se n�o, caso contr�rio do ex�rcicio, acrescenta a soma 7.
		}
		System.out.println("Resultado "+resultado); //System.out.println imprime o texto pulando a linha.
	}
}
