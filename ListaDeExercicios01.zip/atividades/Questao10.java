// Data: 09/09
// Autora: Izabela Fernanda Silva

package atividades;

import java.util.Scanner;

public class Questao10 {
	public static void main(String[] args) {
		Scanner entrada = new Scanner(System.in); //Scanner recebe os valores digitados.
		System.out.println("Velocidade m�xima permitida na avenida:"); //System.out.println imprime o texto pulando a linha.
		int velocidademaxima = entrada.nextInt(); //int declara a vari�vel de velocidade m�xima permitida.
		System.out.println("Velocidade que o motorista dirige: "); //System.out.println imprime o texto pulando a linha.
		int velocidademotorista = entrada.nextInt(); //int declara a vari�vel de velocidade que o motorista est� dirigindo.

		if (velocidademaxima < velocidademotorista) { //if determina a condi��o se o motorista respeitou ou n�o respeitou a lei.
			int diferenca = velocidademotorista - velocidademaxima; //int determinando o calculo da diferen�a da velocidade do motorista e da velocidade m�xima permitida na avenida.
			if (diferenca <= 10) { //if determina a condi��o se a velocidade for menor ou igual a 10.
				System.out.println("Multa de 50,00 reais."); //System.out.println imprime o texto pulando a linha.
			} else if (diferenca <= 30) { //Condi��o se a velocidade for menor ou igual a 30.
				System.out.println("Multa de 100,00 reais."); //System.out.println imprime o texto pulando a linha.
			} else if (diferenca >= 30) { //else if, determina a condi��o se a velocidade for maior ou igual a 30.
				System.out.println("Multa de 200,00 reais."); //System.out.println imprime o texto pulando a linha.
			}
		} else {
			System.out.println("Motorista respeitou a lei."); //System.out.println imprime o texto pulando a linha.
		}

	}

}
