
// Data: 08/09
// Autora: Izabela Fernanda Silva

package atividades;
import java.util.Scanner;
public class Questao05 {
	public static void main(String[] args) {
		Scanner entrada = new Scanner(System.in); //Scanner recebe os valores digitados.
		System.out.println("Insira o valor da di�ria: "); //System.out.println imprime o texto pulando a linha.
		int valor = entrada.nextInt(); //int declarando a vari�vel. 
		float valorPromocional = valor - valor/100*25;  //float, calculando a diferen�a e adicionando os 25%.
		System.out.println("O valor da di�ria promocional � de: "); //System.out.println imprime o texto pulando a linha.
		System.out.println(valorPromocional); //System.out.println imprime o texto pulando a linha.
		float valorTotal = valorPromocional * 75/100*80; //float, calculando a diferen�a e adicionando os 80%.
		System.out.println("O valor total arrecadado com 80% de ocupa��o e di�ria promocional � de: "); //System.out.println imprime o texto pulando a linha.
		System.out.println(valorTotal); //System.out.println imprime o texto pulando a linha.
		float valorTotal1 = valor * 75/100*50; //float, multiplicando o valor total arrecadado e adicionando os 50%.
		System.out.println("O valor total arrecadado com 50% de ocupa��o e di�ria normal � de: "); //System.out.println imprime o texto pulando a linha.
		System.out.println(valorTotal1); //System.out.println imprime o texto pulando a linha.
		float diferen�a = valorTotal - valorTotal1; //float, calculando a diferen�a dos valores.
		System.out.println("A diferen�a entre estes dois valores � de: "); //System.out.println imprime o texto pulando a linha.
		System.out.println(diferen�a); //System.out.println imprime o texto pulando a linha.
		
		
		
		
		
		
		
	}

}
