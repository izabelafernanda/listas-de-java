// Data: 04/09
// Autora: Izabela Fernanda Silva

package atividades;
import java.util.Scanner;
public class Questao04 {
	public static void main(String[] args) {
		Scanner entrada = new Scanner(System.in); //Scanner recebe os valores digitados.
		System.out.println("Insira a nota: ");  //System.out.println imprime o texto pulando a linha.
		int nota = entrada.nextInt(); //int, declarando a vari�vel da nota.
		if (nota >= 8 && nota <=10) //if verifica a condi��o da nota �tima.
		   System.out.print("�timo"); //System.out.println imprime o texto pulando a linha.
		if (nota >=7 && nota <8) //if verifica a condi��o da nota bom. Se maior ou igual a 7 &&(e) menor que 8.
		   System.out.print("bom"); //System.out.println imprime o texto pulando a linha.
		if (nota >=5 && nota <7) //if, verifica a condi��o da nota regular. Se maior ou igual a 5 &&(e) menor que 7.
			System.out.print("regular"); //System.out.println imprime o texto pulando a linha.
		if (nota <5) //if, verifica a condi��o da nota insatisfat�ria. Se menor que 5.
			System.out.println("insatisfat�rio"); //System.out.println imprime o texto pulando a linha.
			
	}

}
