
// Data: 04/09
// Autora: Izabela Fernanda Silva

package atividades;
import java.util.Scanner; 
public class Questao01 {
	public static void main(String[]args) { 
		Scanner entrada = new Scanner(System.in); //Scanner recebe os valores digitados.
		System.out.println("Digite um valor: "); //System.out.println imprime o texto pulando a linha.
		int num1 = entrada.nextInt(); //Declarando a vari�vel do primeiro n�mero.
		System.out.println("Digite outro valor: "); //System.out.println imprime o texto pulando a linha.
		int num2 = entrada.nextInt(); //Declarando a vari�vel do segundo n�mero.
		if (num1 > num2) { //Condi��o if vericando se o n�mero � maior que o outro.
			System.out.println(num1); //System.out.println imprime o texto pulando a linha.
		}else { //Condi��o else verificando se o n�mero � menor ou igual ao outro.
			System.out.println(num2); //System.out.println imprime o texto pulando a linha.
		
		}
	}

}
