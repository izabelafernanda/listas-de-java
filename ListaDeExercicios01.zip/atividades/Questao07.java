
// Data: 09/09
// Autora: Izabela Fernanda Silva

package atividades;

import java.util.Scanner;

public class Questao07 {
	public static void main(String[] args) {
		Scanner entrada = new Scanner(System.in); //Scanner recebe valores digitados.
		System.out.println("Digite o valor do X: "); //System.out.println imprime o texto pulando a linha.
		int x = entrada.nextInt(); //int declara a vari�vel.
		if (x <= 1) //if determina a condi��o de x menor ou igual a 1.
			System.out.println("O valor de Y �: 1"); //System.out.println imprime o texto pulando a linha.
		else if (1<x && x<= 2) //else if determina a condi��o de 1 menor que x, ou x menor ou igual a 2.
			System.out.println("O valor de Y �: 2"); //System.out.println imprime o texto pulando a linha.
		else if (2<x && x<= 3) //else if determina a condi��o de 2 menor ou igual a x ou x menor ou igual a 3.
			System.out.println("O valor de Y �: "+Math.pow(x, 2)); //System.out.println imprime o texto pulando a linha.
		else if (x > 3) //else if determina a condi��o de x maior que 3. 
			System.out.println("O valor de Y �: "+Math.pow(x, 3)); //System.out.println imprime o texto pulando a linha.

	}

}
