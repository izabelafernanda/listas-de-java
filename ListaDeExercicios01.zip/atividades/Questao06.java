
// Data: 08/09
// Autora: Izabela Fernanda Silva

package atividades;
import java.util.Scanner;
public class Questao06 {
	public static void main(String[] args) {
		Scanner entrada = new Scanner(System.in); //Scanner recebe os valores digitados.
		System.out.println("Equa��o do primeiro grau = ax + b = 0"); //System.out.println imprime o texto pulando a linha.
		System.out.println("Insira o valor de a: "); //System.out.println imprime o texto pulando a linha.
		int a = entrada.nextInt(); //int declara a vari�vel de a.
		System.out.println("Insira o valor de b: "); //System.out.println imprime o texto pulando a linha.
		int b = entrada.nextInt(); //int declara a vari�vel de b.
		
		if (a!=0) { //if, condi��o se a for diferente de 0.
			float resultado = b / a; //float, calculando o resultado.
			System.out.printf("O resultado �: %f",resultado); //System.out.println imprime o texto pulando a linha.
		}else { //else, condi��o se a equa��o n�o for do primeiro grau.
			System.out.println("A equa��o n�o � do primeiro grau."); //System.out.println imprime o texto pulando a linha.
			}
	}
}
