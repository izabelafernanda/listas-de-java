//Autor: Izabela Fernanda Silva 
//Data: 17/11/2021

import java.util.Scanner;

public class Questao02 {
    public static void main(String[] args) { //Método principal
        Scanner entrada = new Scanner(System.in); // Objeto para entrada de dados

        System.out.println("Insira aqui um texto: "); // Mensagem para o usuário

        String texto = entrada.nextLine(); // Armazena o texto digitado pelo usuário
        String[] textos = texto.split(" "); // Divide o texto em palavras
        texto = ""; // Inicializa a variável texto

        for (int i = 0; i < textos.length; i++) { // Laço para percorrer as palavras

            if (!textos[i].equals("")) { // Se a palavra não for vazia
                textos[i] = textos[i].trim(); // Remove os espaços em branco
                texto += textos[i] + " "; // Adiciona a palavra ao texto
            }

        }
        System.out.print(texto); // Imprime o texto

    }
}