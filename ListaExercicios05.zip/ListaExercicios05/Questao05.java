//Autor: Izabela Fernanda Silva 
//Data: 17/11/2021

import java.util.Scanner;

public class Questao05 {
    public static void main(String[] args) { //Método principal
        Scanner entrada = new Scanner(System.in);  // Objeto para entrada de dados

        System.out.println("Digite seu número de telefone: "); // Pede para o usuário digitar o número de telefone
        String numero = entrada.nextLine(); // Armazena o número de telefone digitado pelo usuário

        String numeroformat = " "; // String que armazena o número formatado

        for (int i = 0; i < numero.length(); i++) { // Laço para percorrer todo o número digitado pelo usuário

            numeroformat = numeroformat + numero.charAt(i); // Adiciona o caractere ao número formatado

            if (numero.charAt(i) == '-') { // Verifica se o caractere é um traço
                if (numero.length() == 8) { // Verifica se o número de caracteres é 8
                    numero = "9" + numero; // Adiciona o 9 no início do número
                }

            } else if (numero.length() == 8) { // Verifica se o número de caracteres é 8
                numero = "9" + numero; // Adiciona o 9 no início do número
                if (i == 5) { // Verifica se o caractere é o 5º caractere
                    numeroformat += "-"; // Adiciona o traço no final do número
                    numeroformat = "9" + numeroformat; // Adiciona o 9 no início do número formatado
                }

            }

        }
        System.out.println("Telefone possui 8 dígitos. Vou acrescentar o digito 9 na frente. " + numero); // Mostra o número formatado
        System.out.println("Telefone formatado: " + numeroformat); 
    }

}
