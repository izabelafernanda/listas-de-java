//Autor: Izabela Fernanda Silva
// Data: 16/11/2021

import java.util.Scanner;

public class Questao01 {

    
    public static void main(String[] args) { //Método principal
        Scanner entrada = new Scanner(System.in); // Objeto para entrada de dados

        System.out.println("Digite seu nome completo: "); // Imprime na tela

        String nomeCompleto = entrada.nextLine(); // Entrada de dados
        String[] nomes = nomeCompleto.split(" "); // Separa o nome em partes.

        for (int i = 0; i < nomes.length; i++) { // Percorre o vetor

            String nome = nomes[i].toLowerCase(); // Transforma o nome em letras minúsculas
            if (nome.equals("e") || nome.equals("do") || nome.equals("da") || nome.equals("dos") // Verifica se o nome é
                                                                                                 // igual a algum dos
                                                                                                 // nomes
                    || nome.equals("das") || nome.equals("de") || nome.equals("di") || nome.equals("du")) {

                continue; // Pula para o próximo nome
            }
            System.out.print(nomes[i].toUpperCase().charAt(0)); // Imprime a primeira letra do nome
        }

    }
}
