
// Autor: Izabela Fernanda Silva
// Data: 17/11/2021 
import java.util.Scanner;

public class Questao08 {
    public static void main(String[] args) { //Método principal
        Scanner entrada = new Scanner(System.in); // Objeto para entrada de dados

        System.out.println("Digite uma frase: "); // Pede para o usuário digitar algo
        String frase = entrada.nextLine(); // Armazena o que o usuário digitou

        for (int i = 0; i < frase.length(); i++) { // Laço para percorrer a frase
            int codePointAt = frase.codePointAt(i); // Armazena o código do caractere
            codePointAt += 3; // Adiciona 3 ao código do caractere

            if (frase.charAt(i) == ' ') { // Se o caractere for um espaço
                System.out.print(" "); // Imprime um espaço
            } else { // Se não for um espaço
                System.out.print((char) codePointAt); // Imprime o caractere com o código modificado
            }
        }
    }

}
