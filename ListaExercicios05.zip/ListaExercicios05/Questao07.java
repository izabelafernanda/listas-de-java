//Autor: Izabela Fernanda Silva
//Data: 17/11/2021

import java.util.Scanner;

public class Questao07 {
    public static void main(String[] args) { //Método principal
        Scanner entrada = new Scanner(System.in);  // Objeto para entrada de dados

        System.out.println("Digite algo: ");  // Pede para o usuário digitar algo
        String algo = entrada.nextLine(); // Armazena o algo digitado pelo usuário

        for (int i = 0; i < algo.length(); i++) { // Laço para percorrer o algo
            int codePointAt = algo.codePointAt(i); // Armazena o código do caractere na posição i
        
            if (codePointAt >= 65 || codePointAt <= 90) { // Se o código do caractere for maior ou igual a 65 ou menor ou igual a 90
                codePointAt -= 32; // Subtrai 32 do código do caractere
                System.out.print((char)codePointAt); // Imprime o caractere com o código modificado

            }
        } 
    }
    
}
