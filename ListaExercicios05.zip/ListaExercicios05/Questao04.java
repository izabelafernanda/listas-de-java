//Autor: Izabela Fernanda Silva 
//Data: 17/11/2021

import java.util.Scanner;

public class Questao04 {
    public static void main(String[] args) { // Método principal
        Scanner entrada = new Scanner(System.in); // Objeto para entrada de dados

        System.out.println("Digite uma frase: "); // Pede para o usuário digitar uma frase
        String frase = entrada.nextLine(); // Armazena a frase digitada pelo usuário
        palindromo(frase); // Chama o método palindromo
    }

    public static void palindromo(String frase) { // Método que verifica se a frase é um palíndromo

        String fraseInvertida = ""; // Variável que armazena a frase invertida

        for (int i = frase.length() - 1; i >= 0; i--) { // Percorre o vetor de trás para frente, a frase está invertida.
            if (frase.charAt(i) != ' ') { // Se o caractere não for espaço, ele será adicionado na frase invertida.
                fraseInvertida += frase.charAt(i); // Adiciona o caractere na frase invertida
            }
        }

        String frasesemespaco = ""; // Variável que armazena a frase sem espaços

        for (int i = 0; i<= frase.length() - 1; i++) { // Percorre a frase sem espaços.
            if (frase.charAt(i) != ' ') { // Se o caractere não for espaço, ele será adicionado na frase invertida.
                frasesemespaco += frase.charAt(i); // Adiciona o caractere na frase sem espaços
            }
        }
        System.out.println(fraseInvertida); // Imprime a frase invertida.
        if (frasesemespaco.equals(fraseInvertida)) { // Verifica se a frase é um palíndromo.
            System.out.println("A frase é um palíndromo");
        } else { // Se não for um palíndromo, a frase não é um palíndromo.
            System.out.println("A frase não é um palíndromo");
        }
    }}
