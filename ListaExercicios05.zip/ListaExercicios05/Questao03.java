//Autor: Izabela Fernanda  Silva 
// Data: 17/11/2021

import java.util.Scanner;

public class Questao03 {
    public static void main(String[] args) { //Método principal
        Scanner entrada = new Scanner(System.in); // Objeto para entrada de dados

        System.out.println("Digite sua data de nascimento: dd/mm/aaaa"); //Entrada de dados
        String data = entrada.nextLine(); //Recebe a entrada de dados

        String meses[] = { "Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", // Array com os meses
                "Outubro", "Novembro", "Dezembro" };  

        String dataseparada[] = data.split("/");  //Separa a data em partes.

        
        if (dataseparada[1].equals("01")) {  //Verifica se o mês é Janeiro
            System.out.println("Você nasceu em " + dataseparada[0] + " de " + meses[0] + " de " + dataseparada[2]); // Imprime a data de nascimento
        } else if (dataseparada[1].equals("02")) {
            System.out.println("Você nasceu em " + dataseparada[0] + " de " + meses[1] + " de " + dataseparada[2]);
        } else if (dataseparada[1].equals("03")) {
            System.out.println("Você nasceu em " + dataseparada[0] + " de " + meses[2] + " de " + dataseparada[2]);
        } else if (dataseparada[1].equals("04")) {
            System.out.println("Você nasceu em " + dataseparada[0] + " de " + meses[3] + " de " + dataseparada[2]);
        } else if (dataseparada[1].equals("05")) {
            System.out.println("Você nasceu em " + dataseparada[0] + " de " + meses[4] + " de " + dataseparada[2]);
        } else if (dataseparada[1].equals("06")) {
            System.out.println("Você nasceu em " + dataseparada[0] + " de " + meses[5] + " de " + dataseparada[2]);
        } else if (dataseparada[1].equals("07")) {
            System.out.println("Você nasceu em " + dataseparada[0] + " de " + meses[6] + " de " + dataseparada[2]);
        } else if (dataseparada[1].equals("08")) {
            System.out.println("Você nasceu em " + dataseparada[0] + " de " + meses[7] + " de " + dataseparada[2]);
        } else if (dataseparada[1].equals("09")) {
            System.out.println("Você nasceu em " + dataseparada[0] + " de " + meses[8] + " de " + dataseparada[2]);
        } else if (dataseparada[1].equals("10")) {
            System.out.println("Você nasceu em" + dataseparada[0] + " de " + meses[9] + " de " + dataseparada[2]);
        } else if (dataseparada[1].equals("10")) {
            System.out.println("Você nasceu em" + dataseparada[0] + " de " + meses[10] + " de " + dataseparada[2]);
        } else if (dataseparada[1].equals("10")) { 
                System.out.println("Você nasceu em" + dataseparada[0] + " de " + meses[11] + " de " + dataseparada[2]);
        }
    }
}
