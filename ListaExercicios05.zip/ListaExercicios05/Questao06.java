//Autor: Izabela Fernanda Silva 
//Data: 17/11/2021

import java.util.Scanner;

public class Questao06 {
    public static void main(String[] args) { //Método principal
        Scanner entrada = new Scanner(System.in); // Objeto para entrada de dados

        System.out.println("Digite uma palavra: "); // Pede para o usuário digitar uma palavra
        String palavra = entrada.nextLine(); // Armazena a palavra digitada pelo usuário

        for (int i = 0; i < palavra.length(); i++) { // Laço para percorrer a palavra
            System.out.println(palavra.charAt(i)); // Imprime o caractere da posição i da palavra
            for (int j = 0; j <= i; j++) { // Laço para percorrer a palavra
                System.out.print(" "); // Imprime um espaço
            }
        }
    }
}